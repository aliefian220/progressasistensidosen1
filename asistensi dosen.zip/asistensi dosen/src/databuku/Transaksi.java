package databuku;

import java.time.LocalDate;

public class Transaksi {
    private String idTransaksi;
    private Member member;
    private Buku buku;
    private LocalDate tanggalPinjam;
    private LocalDate tanggalKembali;

    public Transaksi(String idTransaksi, Member member, Buku buku) {
        this.idTransaksi = idTransaksi;
        this.member = member;
        this.buku = buku;
        this.tanggalPinjam = LocalDate.now();
        this.tanggalKembali = null;
    }

    public String getIdTransaksi() {
        return idTransaksi;
    }

    public Member getMember() {
        return member;
    }

    public Buku getBuku() {
        return buku;
    }

    public LocalDate getTanggalPinjam() {
        return tanggalPinjam;
    }

    public LocalDate getTanggalKembali() {
        return tanggalKembali;
    }

    public void setTanggalKembali(LocalDate tanggalKembali) {
        this.tanggalKembali = tanggalKembali;
    }

    public boolean isReturned() {
        return tanggalKembali != null;
    }
}
