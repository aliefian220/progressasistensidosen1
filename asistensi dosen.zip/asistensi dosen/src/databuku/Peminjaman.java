package databuku;

public class Peminjaman {
    private Member member;
    private Buku buku;

    // Constructor Peminjaman
    public Peminjaman(Member member, Buku buku) {
        this.member = member;
        this.buku = buku;
    }

    public void pinjamBuku() {
        if (buku.getStok() > 0) {
            buku.setStok(buku.getStok() - 1);
            System.out.println("Buku " + buku.getJudul() + " dipinjam oleh " + member.getNama());
        } else {
            System.out.println("Stok buku " + buku.getJudul() + " habis.");
        }
    }

    public void kembalikanBuku() {
        buku.setStok(buku.getStok() + 1);
        System.out.println("Buku " + buku.getJudul() + " dikembalikan oleh " + member.getNama());
    }
}
