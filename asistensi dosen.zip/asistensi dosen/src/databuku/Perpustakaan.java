package databuku;

import java.util.ArrayList;

public class Perpustakaan {
    private ArrayList<Buku> daftarBuku;
    private ArrayList<Member> daftarMember;
    private ArrayList<Transaksi> daftarTransaksi;

    public Perpustakaan() {
        daftarBuku = new ArrayList<>();
        daftarMember = new ArrayList<>();
        daftarTransaksi = new ArrayList<>();
    }

    public void tambahBuku(Buku buku) {
        daftarBuku.add(buku);
    }

    public void tambahMember(Member member) {
        daftarMember.add(member);
    }

    public ArrayList<Buku> getDaftarBuku() {
        return daftarBuku;
    }

    public ArrayList<Member> getDaftarMember() {
        return daftarMember;
    }

    public ArrayList<Transaksi> getDaftarTransaksi() {
        return daftarTransaksi;
    }

    public void pinjamBuku(Member member, Buku buku) {
        if (buku.isAvailable()) {
            buku.setStok(buku.getStok() - 1);
            String idTransaksi = "T" + (daftarTransaksi.size() + 1);
            Transaksi transaksi = new Transaksi(idTransaksi, member, buku);
            daftarTransaksi.add(transaksi);
        }
    }

    public void kembalikanBuku(String idTransaksi) {
        for (Transaksi transaksi : daftarTransaksi) {
            if (transaksi.getIdTransaksi().equals(idTransaksi) && !transaksi.isReturned()) {
                transaksi.setTanggalKembali(java.time.LocalDate.now());
                transaksi.getBuku().setStok(transaksi.getBuku().getStok() + 1);
                return;
            }
        }
    }
}
