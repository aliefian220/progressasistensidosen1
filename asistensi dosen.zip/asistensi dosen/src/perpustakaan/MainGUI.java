package perpustakaan;

import databuku.Buku;
import databuku.Member;
import databuku.Perpustakaan;
import databuku.Transaksi;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainGUI {
    private JFrame frame;
    private Perpustakaan perpustakaan;
    private JComboBox<String> comboBoxBuku, comboBoxMember;
    private JTextArea textArea;

    public MainGUI() {
        perpustakaan = new Perpustakaan();

        // Tambah data awal
        perpustakaan.tambahBuku(new Buku("111", "Pemrograman Jaringan", 10));
        perpustakaan.tambahBuku(new Buku("112", "Pemrograman Web", 20));
        perpustakaan.tambahBuku(new Buku("113", "pemograman socket jaringan komputer mengunakan HTTP dan snmpt", 10));
        perpustakaan.tambahBuku(new Buku("114", "matematika diskrit", 15));
        perpustakaan.tambahBuku(new Buku("115", "grafika komputer", 20));
        perpustakaan.tambahBuku(new Buku("116", "riset operasi", 10));
        perpustakaan.tambahBuku(new Buku("117", "toefl", 5));
        perpustakaan.tambahBuku(new Buku("118", "sejarah dan kebudayaan islam", 12));
        perpustakaan.tambahMember(new Member("07282", "Jonathan anandar cahyadi"));
        perpustakaan.tambahMember(new Member("90142", "citra nurina prabbiantissa"));
        perpustakaan.tambahMember(new Member("07677", "Iqtifarsya Dewita Santoso "));
        perpustakaan.tambahMember(new Member("90525", "Ayu Permata Widya Nurizma "));
        perpustakaan.tambahMember(new Member("07556", "damai deo saputra "));
        perpustakaan.tambahMember(new Member("07654", "Amelya Sofia Anggraini"));
        perpustakaan.tambahMember(new Member("07454", "muhammad mahameru abidin"));
        perpustakaan.tambahMember(new Member("07574", "Mas ryansyah ahmad"));
        perpustakaan.tambahMember(new Member("07512", "Moch Faris Zakaria"));
        perpustakaan.tambahMember(new Member("90527", "aliefian rizky subagia"));

        initialize();
    }

    private void initialize() {
        frame = new JFrame("Manajemen Perpustakaan");
        frame.setSize(600, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Panel Buku dan Member
        JPanel panel = new JPanel(new FlowLayout());

        JLabel labelBuku = new JLabel("Pilih Buku:");
        comboBoxBuku = new JComboBox<>();
        for (Buku buku : perpustakaan.getDaftarBuku()) {
            comboBoxBuku.addItem(buku.getIdBuku() + " - " + buku.getJudul() + " (Stok: " + buku.getStok() + ")");
        }

        JLabel labelMember = new JLabel("Pilih Member:");
        comboBoxMember = new JComboBox<>();
        for (Member member : perpustakaan.getDaftarMember()) {
            comboBoxMember.addItem(member.getIdMember() + " - " + member.getNama());
        }

        JButton buttonPinjam = new JButton("Pinjam Buku");
        buttonPinjam.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                pinjamBuku();
            }
        });

        JButton buttonTampilkanTransaksi = new JButton("Tampilkan Transaksi");
        buttonTampilkanTransaksi.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tampilkanTransaksi();
            }
        });

        panel.add(labelBuku);
        panel.add(comboBoxBuku);
        panel.add(labelMember);
        panel.add(comboBoxMember);
        panel.add(buttonPinjam);
        panel.add(buttonTampilkanTransaksi);

        // Panel Output
        textArea = new JTextArea();
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);

        frame.add(panel, BorderLayout.NORTH);
        frame.add(scrollPane, BorderLayout.CENTER);
        frame.setVisible(true);
    }

    private void pinjamBuku() {
        String selectedBuku = (String) comboBoxBuku.getSelectedItem();
        String selectedMember = (String) comboBoxMember.getSelectedItem();

        if (selectedBuku != null && selectedMember != null) {
            String idBuku = selectedBuku.split(" - ")[0];
            String idMember = selectedMember.split(" - ")[0];

            Buku buku = perpustakaan.getDaftarBuku().stream().filter(b -> b.getIdBuku().equals(idBuku)).findFirst().orElse(null);
            Member member = perpustakaan.getDaftarMember().stream().filter(m -> m.getIdMember().equals(idMember)).findFirst().orElse(null);

            if (buku != null && member != null && buku.isAvailable()) {
                perpustakaan.pinjamBuku(member, buku);
                textArea.append("Buku '" + buku.getJudul() + "' berhasil dipinjam oleh " + member.getNama() + "\n");
                updateComboBoxBuku();
            } else {
                textArea.append("Buku tidak tersedia atau invalid!\n");
            }
        }
    }

    private void tampilkanTransaksi() {
        textArea.append("\nDaftar Transaksi:\n");
        for (Transaksi transaksi : perpustakaan.getDaftarTransaksi()) {
            textArea.append("ID Transaksi: " + transaksi.getIdTransaksi() + ", Member: " + transaksi.getMember().getNama() +
                    ", Buku: " + transaksi.getBuku().getJudul() +
                    ", Tanggal Pinjam: " + transaksi.getTanggalPinjam() +
                    ", Tanggal Kembali: " + (transaksi.isReturned() ? transaksi.getTanggalKembali() : "Belum Dikembalikan") + "\n");
        }
    }

    private void updateComboBoxBuku() {
        comboBoxBuku.removeAllItems();
        for (Buku buku : perpustakaan.getDaftarBuku()) {
            comboBoxBuku.addItem(buku.getIdBuku() + " - " + buku.getJudul() + " (Stok: " + buku.getStok() + ")");
        }
    }

    public static void main(String[] args) {
        new MainGUI();
    }
}
